import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Box,
  Typography,
  TextField,
  Card,
  Button,
  Divider,
  Grid,
  Avatar,
  IconButton,
  Chip,
  useTheme
} from "@mui/material";
import { Search, Close, Refresh, OpenInNew, Diamond } from "@mui/icons-material";
import { useLeaderboardData } from "../scripts/leaderboard.js";

import UserDetailsPopup from "./userDetailsPopup"; // A popup importálása

const Leaderboard = () => {
  const theme = useTheme();
  const [quote, setQuote] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUserForPopup, setSelectedUserForPopup] = useState(null);
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [error, setError] = useState(null);

  const {
    mutate: loadLeaderboardData,
    isLoading,
    data: fetchedLeaderboardData,
  } = useLeaderboardData();

  useEffect(() => {
    if (fetchedLeaderboardData) {
      const sortedData = [...fetchedLeaderboardData].sort((a, b) => {
        const pointsA = Number(a.rank?.points || 0);
        const pointsB = Number(b.rank?.points || 0);
        return pointsB - pointsA;
      });
      setLeaderboardData(sortedData);
    }
  }, [fetchedLeaderboardData]);

  const handleSearch = (event) => {
    const value = event.target.value;
    setSearchTerm(value);
  };

  const clearSearch = () => {
    setSearchTerm("");
  };

  const getProfilePicture = (user) => {
    if (!user?.profilPic) return "/path/to/default/profile-pic.png"; // alapértelmezett kép
    return `data:image/jpeg;base64,${user.profilPic}`; // felhasználói profilkép
  };

  return (
    <Box sx={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: `url('/premium-gym-bg.jpg') no-repeat center center fixed`,
      backgroundSize: 'cover',
      color: '#fff',
    }}>
      <Box sx={{ flex: 1, p: 4 }}>
        <Typography variant="h3" sx={{ color: "#d4af37", fontWeight: 700, mb: 4 }}>
          Ranglista <Diamond sx={{ color: '#d4af37', fontSize: '1.2em' }} />
        </Typography>

        {/* Search bar */}
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Keresés a ranglistán..."
          value={searchTerm}
          onChange={handleSearch}
          InputProps={{
            startAdornment: <Search sx={{ color: "#d4af37", mr: 1 }} />,
            endAdornment: searchTerm && (
              <IconButton onClick={clearSearch} size="small">
                <Close sx={{ color: "rgba(255,255,255,0.5)", fontSize: 18 }} />
              </IconButton>
            ),
          }}
          sx={{
            mb: 4,
            '& .MuiOutlinedInput-root.Mui-focused': {
              borderColor: '#d4af37',
            }
          }}
        />

        <Grid container spacing={4}>
          <Grid item xs={12} lg={8}>
            <Box sx={{ display: "flex", justifyContent: "center", flexDirection: "column" }}>
              {leaderboardData.map((user, index) => (
                <Box
                  key={user.id}
                  onClick={() => setSelectedUserForPopup(user)} // Kattintásra a popup bejön
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    p: 2,
                    borderBottom: '1px solid rgba(255,255,255,0.1)',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      backgroundColor: 'rgba(212, 175, 55, 0.1)',
                    },
                  }}
                >
                  <Avatar
                    src={getProfilePicture(user)}
                    sx={{ width: 42, height: 42, mr: 2 }}
                  />
                  <Typography sx={{ fontWeight: 500, color: '#fff' }}>{user.username}</Typography>
                </Box>
              ))}
            </Box>
          </Grid>
        </Grid>
      </Box>

      {/* Popup Display */}
      {selectedUserForPopup && (
        <UserDetailsPopup
          user={selectedUserForPopup}
          onClose={() => setSelectedUserForPopup(null)} // Bezáráskor eltűnik
        />
      )}
    </Box>
  );
};

export default Leaderboard;
